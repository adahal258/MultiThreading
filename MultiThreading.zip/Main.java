// Name: Aashutosh Dahal
// Class: 2251: A01
// Assignment: MultiThreading.
// Purpose: To create a thread using threadDemo class that extends thread.
// Filename: "Main.java"

public class Main
{
	public static void main(String args[])
	{
		//Create new instances of ThreadDemo:
		ThreadDemo T1 = new ThreadDemo(0,"Aashutosh");
		ThreadDemo T2 = new ThreadDemo(0,"Dahal");

		//Start up both ThreadDemo objects:
		T1.start();
		T2.start();
		
		//Wait on the threads to finish.
		try{
			T1.join();
			T2.join();
		}catch(InterruptedException e){
			System.out.println("Interrupted");
		}
		
		System.out.println("\nFINISHED\n");
	}
}