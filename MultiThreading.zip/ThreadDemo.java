// Name: Aashutosh Dahal
// Class: 2251: A01
// Assignment: Multithreading.
// Purpose: To create a ThreadDemo class that inherits Thread.
// Filename: "ThreadDemo.java"
public class ThreadDemo extends Thread
{
	private int start;
	private String identifier;
	
	public ThreadDemo(int start, String identifier)
	{
		this.start = start;
		this.identifier = identifier;
	}
	
	public void run()
	{
		for(int i=start; i<10000; i++)
			System.out.println(identifier+": "+i);
	}
}